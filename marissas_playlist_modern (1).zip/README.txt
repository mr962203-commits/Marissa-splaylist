Marissa's Playlist - Modern Website
----------------------------------
Files included:
- index.html
- images/ (5 album covers)

Quick publish to GitHub Pages (web UI):
1. Create a free GitHub account at https://github.com/ if you don't have one.
2. Create a new public repository named 'marissas-playlist'.
3. Upload index.html and the images folder (use Add file → Upload files).
4. Commit changes.
5. Go to Settings → Pages (or Code and automation → Pages), select branch 'main' and folder '/', Save.
6. After a few minutes your site will be live at https://<your-username>.github.io/marissas-playlist/

If you'd like, I can guide you step-by-step while you upload the files.
